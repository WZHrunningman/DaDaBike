# libzxing

zxing Android lib简化包

五分钟实现Android扫码识别：http://blog.csdn.net/qq_17475155/article/details/51607141
